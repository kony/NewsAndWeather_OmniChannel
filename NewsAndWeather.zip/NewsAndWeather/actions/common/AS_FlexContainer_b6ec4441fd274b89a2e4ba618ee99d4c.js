function AS_FlexContainer_b6ec4441fd274b89a2e4ba618ee99d4c(eventobject) {
    var self = this;
    this.showAccord("flexAcc1");
}