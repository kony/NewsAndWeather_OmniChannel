function AS_FlexContainer_i1a385eee9994b9a8dcf0c9cc310e557(eventobject) {
    // if(this.view.lblCodeSnippet.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}