function AS_Segment_dfcca9ad344549429be92720540ec2ef(eventobject) {
    var self = this;
    alert("onpull");
}