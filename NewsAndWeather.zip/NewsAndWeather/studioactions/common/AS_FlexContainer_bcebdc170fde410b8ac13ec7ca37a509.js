function AS_FlexContainer_bcebdc170fde410b8ac13ec7ca37a509(eventobject) {
    var self = this;
    this.onClickBack();
}