function AS_Button_ifc70f744faa4573b02b453683ce8fcf(eventobject) {
    var self = this;
    this.onClickPlayButton(eventobject.id);
}