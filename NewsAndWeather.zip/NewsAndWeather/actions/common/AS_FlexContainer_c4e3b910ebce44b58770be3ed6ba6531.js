function AS_FlexContainer_c4e3b910ebce44b58770be3ed6ba6531(eventobject) {
    var self = this;
    this.onLinkClick();
}