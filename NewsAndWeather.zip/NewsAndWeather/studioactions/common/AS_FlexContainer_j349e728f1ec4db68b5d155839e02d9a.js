function AS_FlexContainer_j349e728f1ec4db68b5d155839e02d9a(eventobject) {
    var self = this;
    this.closeWhenDone();
}