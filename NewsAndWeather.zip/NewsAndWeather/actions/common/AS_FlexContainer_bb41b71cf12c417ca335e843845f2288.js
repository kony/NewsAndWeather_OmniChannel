function AS_FlexContainer_bb41b71cf12c417ca335e843845f2288(eventobject) {
    var self = this;
    this.view.segGetStarted.pageSkin = "sknpaging";
}