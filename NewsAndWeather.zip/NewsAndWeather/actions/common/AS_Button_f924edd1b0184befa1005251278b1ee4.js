function AS_Button_f924edd1b0184befa1005251278b1ee4(eventobject) {
    var self = this;
    this.onGetStarted();
}