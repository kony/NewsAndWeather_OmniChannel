function AS_FlexContainer_h3222d9aeccd4c388a760c960bc88189(eventobject) {
    var self = this;
    // if(this.view.rchtextDoc.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}