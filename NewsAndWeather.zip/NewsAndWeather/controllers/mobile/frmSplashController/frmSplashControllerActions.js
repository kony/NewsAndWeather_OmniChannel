define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Form_b7026e7131ee48358cd564ace8b34c03: function AS_Form_b7026e7131ee48358cd564ace8b34c03(eventobject) {
        var self = this;
        this.setGetStartedData();
    }
});