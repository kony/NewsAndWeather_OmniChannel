define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Form_ed8eb8dba2594bbf927d993c808f8411: function AS_Form_ed8eb8dba2594bbf927d993c808f8411(eventobject) {
        var self = this;
        this.onPreshow();
    }
});