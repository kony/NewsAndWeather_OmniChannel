function AS_FlexContainer_d40d33aab67d4319bfcbe00231aff726(eventobject) {
    var self = this;
    // if(this.view.rchTextDesc.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}