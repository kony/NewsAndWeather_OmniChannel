function AS_Button_fcbdeda94c7b4fd7bc7508403db3c17f(eventobject) {
    var self = this;
    this.onClickNext();
}