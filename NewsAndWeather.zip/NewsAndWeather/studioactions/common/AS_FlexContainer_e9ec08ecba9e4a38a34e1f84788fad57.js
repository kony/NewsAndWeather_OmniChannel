function AS_FlexContainer_e9ec08ecba9e4a38a34e1f84788fad57(eventobject) {
    var self = this;
    // if(this.view.lblCodeSnippet.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}