function AS_FlexContainer_c9068f8025ab4961b819887518d105a4(eventobject) {
    // if(this.view.rchtextDoc.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}