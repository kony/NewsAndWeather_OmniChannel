//
//  KSConstants.h
//  KonySyncV2
//
//  Created by Manikanta on 27/09/16.
//  Copyright © 2016 Kony. All rights reserved.
//

#import <Foundation/Foundation.h>

@class SyncError;
@class Stats;

//constants for SyncEngine
#define COMPLETION_HANDLER @"completionHandler"

//Names of subTasks for ClientDBSetupTask
#define METADATA_MANAGER  @"MetadataManager"
#define METADATA_REFRESH_STATUS @"Metadata Refresh Status"
#define SCHEMA_PARSER_TASK @"SchemaParserTask"
#define TABLE_CREATOR_TASK @"TableCreatorTask"
#define METADATA_JSON_PARSER @"MetadataJSONParser"
#define DB_SCHEMA_SETUP_TASK @"DBSchemaSetupTask"
#define METADATA_TABLE_UTILS @"MetadataTableUtils"
#define META_TABLE_SETUP_TASK @"MetaTableSetupTask"
#define METADATA_QUERYING_TASK @"MetadataTableQueryingTask"
#define METADATA_REFRESHER_TASK @"MetadataRefresherTask"
#define METADATA_DOWNLOADER_TASK @"MetadataDownloaderTask"
#define GENERIC_DATA_FETCHER_TASK @"GenericDataFetcherTask"
#define METADATA_TABLE_JSON_UPDATER @"MetadataTableUpdaterTask"
#define METADATA_QUERY_GENERATOR_TASK @"MetadataQueryGeneratorTask"
#define SYNC_TASK @"SyncTask"

//Names of generic subTasks
#define NETWORK_TASK @"NetworkTask"

//Input/Output parameters for Setup
#define OBJECTSERVICE_URL @"url"
#define OBJECTSERVICE_METADATA_URL @"metadata_url"
#define VERSION @"version"
#define APP_CONTEXT @"appContext"
#define HTTP_METHOD @"HTTPMethod"
#define SQL_DDL_STATEMENTS @"sql_ddl"
#define SYNC_SERVER_URL @"syncServerURL"
#define META_TABLE_QUERIES @"MetaTableQueries"
#define SYNC_SERVER_METADATA_URL @"metadata_url"
#define OBJECT_SERVICE_NAME @"objectServiceName"
#define ROOT_METADATA_OBJECT @"rootMetadataObject"
#define METADATA_JSON_STRING @"metadataJSONString"
#define OBJECT_SERVICES_CONTEXT @"objectServicesContext"
#define IS_DELTA_CONTEXT_CHANGED @"isDeltaContextChanged"
#define SHOULD_CREATE_OBJECT_TABLES @"shouldCreateObjectTables"

// Upload Payload Keys
#define METADATA @"metadata"
#define CHECKSUM @"checksum"
#define _METADATA @"_metadata"
#define SESSIONID @"sessionID"
#define ECHO @"echo"
#define HAS_MORE_RECORDS @"hasMoreRecords"
#define ABORT_ON_ERROR @"abortonError"
#define ROW_ID @"rowId"

// Param Names
#define ARE_THERE_CHANGES_TO_UPLOAD @"areThereDeltaChanges"
#define UPLOAD_FAILED_OBJECTS @"failureObjects"
#define DATA_OBJECTS @"dataObjects"
#define UPLOAD_RESPONSE_OBJECTS @"uploadObjects"
#define UPLOAD_RESPONSE_METADATA @"uploadResponseMetadata"
#define DELEGATE_TASK_COMMAND @"DelegateTaskCommand"
#define RESPONSE_METADATA @"responseMetadata"
#define SYNC_OBJECT @"SyncObject"
#define DELTA_CONTEXT @"delta_context"
#define OBJECT_NAME_KEY_IN_DELTA_CONTEXT @"object_name"
#define DOWNLOAD_RESPONSE_METADATA @"downloadResponseMetadata"
#define OBJECT_DOWNLOAD_RESPONSE_MAP @"objectDownloadResponseMap"
#define URL_KEYWORD @"url"
#define REQUEST_BODY @"request_body"
#define REQUEST_HEADERS @"request_headers"
#define QUERY_PARAMS @"query_params"
#define DATA_DICTIONARY @"dataDictionary"
#define METADATA_OBJECT @"metadataObject"
#define RESPONSE_METADATA @"responseMetadata"
#define DOWNLOAD_METADATA @"downloadMetadata"
#define UPLOAD_METADATA @"uploadMetadata"
#define OBJECT_RECORDS @"object_records"
#define OBJECT_GROUP @"objectgroup"
#define OBJECT_SERVICE @"objectservice"
#define OBJECT_NAME @"objectname"
#define FILTER @"filter"
#define DELTACONTEXT @"deltacontext"
#define DOLLAR_FILTER @"$filter"
#define DOLLAR_FILTER_EQUALS_TO @"$filter="
#define DOLLAR_EXPAND @"$expand"
#define DOLLAR_EXPAND_EQUALS_TO @"$expand="
#define ODATASTRING @"odatastring"
#define SYNC_OPTIONS @"syncOptions"
#define BATCH_SIZE @"BatchSize"


//Key Constant
#define kName @"name"

//Delta context parsing
#define DELTA @"delta"
#define OBJS @"objs"

//Skip Validation
#define SKIP_VALIDATION @"skipValidation"

#define MAX_PASS_COUNT_FOR_HIERARCHICAL_UPLOADS 10

typedef enum{
    SyncLevelObject,
    SyncLevelObjectService,
    SyncLevelApplication
}SyncLevel;

typedef enum {
    DelegateTaskCommandNone = 0,
    DelegateTaskCommandDataUpload,
    DelegateTaskCommandDataDownload
}DelegateTaskCommand;

typedef enum {
    KSSDKObjectRecordActionUpdate = 0,
    KSSDKObjectRecordActionCreate = 1,
    KSSDKObjectRecordActionPartialUpdate = 2,
    KSSDKObjectRecordActionDelete = 3,
    KSSDKObjectRecordActionCreateOrIgnore = 4,
    KSSDKObjectRecordActionAll = 5,
    KSSDKObjectRecordActionNone = 6,
    KSSDKObjectRecordActionRead = 7,
    KSSDKObjectRecordActionUnknown = KSSDKObjectRecordActionUpdate
}KSSDKObjectRecordAction;

typedef enum {
    KSSDKObjectActionUpdate = 0,
    KSSDKObjectActionCreate,
    KSSDKObjectActionCreateOrIgnore,
    KSSDKObjectActionRead,
    KSSDKObjectActionPartialUpdate,
    KSSDKObjectActionDelete,
    KSSDKObjectActionNone = KSSDKObjectActionUpdate
}KSSDKObjectAction;

typedef enum {
    KSSDKObjectModeOffline = 0,
    KSSDKObjectModeOnline
}KSSDKObjectMode;

typedef enum {
    SyncSessionStateNotStarted = 0,
    SyncSessionStateStarted,
    SyncSessionStatePausing,
    SyncSessionStatePaused,
    SyncSessionStateResuming,
    SyncSessionStateStopping,
    SyncSessionStateEnded,
    SyncSessionStateErrored,
    SyncSessionStateProgress
}SyncSessionState;

//TODO: Add more phases as required...
//What about Errors?
typedef enum {
    SyncSessionPhaseUnknown = 0,
    
    //Setup session start
    SyncSessionPhaseSetup,
    
    //Upload session start
    SyncSessionPhaseUpload,
    
    //Upload Network Calls
    SyncSessionPhaseUploadNetworkOperation,
    
    //Response processing
    SyncSessionPhaseUploadObjectProcessing,
    
    // Commiting to DB
    SyncSessionPhaseUploadPersistOperation,
    
    //Download Session start
    SyncSessionPhaseDownload,
    
    //Download Network Calls
    SyncSessionPhaseDownloadNetworkOperation,
    
    //Response processing
    SyncSessionPhaseDownloadObjectProcessing,
    
    //Commiting to DB
    SyncSessionPhaseDownloadPersistOperation,
    
    //Sync Session
    SyncSessionPhaseSync
    
}SyncSessionPhase;

typedef enum{
    Ascending,
    Descending
}KSOrderBySortingType;

typedef enum{
    Select
}KSSQLQueryType;

//Options for Sync Stats
typedef enum {
    True,
    False,
    All
} KSStatsOptionsConstants;

/**
 Generic completion handler which gets invoked after a specific
 action is done (for eg: Sync start session).
 
 @param error If an error occurred during the action, then the error will be
 non-null and will indicate the error.
 */
typedef void(^CompletionHandler)(NSDictionary<NSString *, id> *object, SyncError *error);

/**
 Facade layer success completion handler.

 @param object nullable output object.
 */
typedef void (^SuccessCompletionHandler) (id object);

/**
 Facade layer failure completion handler.

 @param error nullbale error object.
 */
typedef void (^FailureCompletionHandler) (NSError *error);

/**
 Facade layer sync progress completion handler.
 
 @param object nullable output object.
 */
typedef void (^SyncProgressCompletionHandler) (id object);

