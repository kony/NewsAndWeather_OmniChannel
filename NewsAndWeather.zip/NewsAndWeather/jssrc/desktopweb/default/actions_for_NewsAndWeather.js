//actions.js file 
function AS_Button_a26c85d3b5b64e77badfc762ba65d981(eventobject) {
    var self = this;
    this.openEmail();
}

function AS_Button_ab9d53d5558c4ba1af5045b4154b972d(eventobject) {
    var self = this;
    this.onClickPrev();
}

function AS_Button_b7c93521371e4abd850f63754d2bd3c8(eventobject) {
    var self = this;
    this.onGetStarted();
}

function AS_Button_c5b644cc89214b9b91e0ec4ae2c90260(eventobject) {
    var self = this;
    this.onClickPlayButton(eventobject.id);
}

function AS_Button_d35edc11a27e42b28e76d53809c6daf7(eventobject) {
    var self = this;
    this.onClickPlayButton(eventobject.id);
}

function AS_Button_f924edd1b0184befa1005251278b1ee4(eventobject) {
    var self = this;
    this.onGetStarted();
}

function AS_Button_f9e7b46299ed44238d0f3181e67ddbbc(eventobject) {
    var self = this;
    this.onGetStarted();
}

function AS_Button_fcbdeda94c7b4fd7bc7508403db3c17f(eventobject) {
    var self = this;
    this.onClickNext();
}

function AS_Button_ifc70f744faa4573b02b453683ce8fcf(eventobject) {
    var self = this;
    this.onClickPlayButton(eventobject.id);
}

function AS_Button_jf7ec43e72814d60aadf22cdef2aa6b6(eventobject) {
    var self = this;
    this.onClickPlayButton(eventobject.id);
}

function AS_FlexContainer_abbbd3c02ea345acae74375d13194554(eventobject) {
    var self = this;
    // if(this.view.rchtextDoc.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}

function AS_FlexContainer_b6ec4441fd274b89a2e4ba618ee99d4c(eventobject) {
    var self = this;
    this.showAccord("flexAcc1");
}

function AS_FlexContainer_bb41b71cf12c417ca335e843845f2288(eventobject) {
    var self = this;
    this.view.segGetStarted.pageSkin = "sknpaging";
}

function AS_FlexContainer_bcebdc170fde410b8ac13ec7ca37a509(eventobject) {
    var self = this;
    this.onClickBack();
}

function AS_FlexContainer_c048300a3ec34ffd93bc4493926ec85e(eventobject) {
    var self = this;
    // if(this.view.lblCodeSnippet.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}

function AS_FlexContainer_c4e3b910ebce44b58770be3ed6ba6531(eventobject) {
    var self = this;
    this.onLinkClick();
}

function AS_FlexContainer_c9068f8025ab4961b819887518d105a4(eventobject) {
    // if(this.view.rchtextDoc.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}

function AS_FlexContainer_cf29c72c3dce451c9e764b20780997a5(eventobject) {
    // if(this.view.rchtextDoc.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}

function AS_FlexContainer_d40d33aab67d4319bfcbe00231aff726(eventobject) {
    var self = this;
    // if(this.view.rchTextDesc.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}

function AS_FlexContainer_df4e57dc26134923b04582e9bbf12332(eventobject) {
    var self = this;
}

function AS_FlexContainer_e007ca5e942e474fa13735d61e8be717(eventobject) {
    var self = this;
    // if(this.view.rchTextDesc.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}

function AS_FlexContainer_e9ec08ecba9e4a38a34e1f84788fad57(eventobject) {
    var self = this;
    // if(this.view.lblCodeSnippet.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}

function AS_FlexContainer_eb36dc9d1d454a4db5a8ee39a0e85b9b(eventobject) {
    var self = this;
    this.onClickBack();
}

function AS_FlexContainer_f1bef0092c2d47778962efa6e1bd8c9e(eventobject) {
    var self = this;
    this.showFirstScreen();
}

function AS_FlexContainer_f40a9391cecc4a818de2d369521107be(eventobject) {
    // if(this.view.rchTextDesc.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}

function AS_FlexContainer_ge13e3a87b774a75bd5e3df8c9b08f09(eventobject) {
    // if(this.view.rchTextDesc.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}

function AS_FlexContainer_h3222d9aeccd4c388a760c960bc88189(eventobject) {
    var self = this;
    // if(this.view.rchtextDoc.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}

function AS_FlexContainer_hc44409934fe4a7c87a833420573c456(eventobject) {
    // if(this.view.lblCodeSnippet.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}

function AS_FlexContainer_i1a385eee9994b9a8dcf0c9cc310e557(eventobject) {
    // if(this.view.lblCodeSnippet.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}

function AS_FlexContainer_j349e728f1ec4db68b5d155839e02d9a(eventobject) {
    var self = this;
    this.closeWhenDone();
}

function AS_FlexContainer_jf582ae16db246a8aa7078364c207959(eventobject) {
    var self = this;
    this.closeWhenDone();
}

function AS_Image_d320d00c85004d1bb1e06a8e56d810f0(eventobject, x, y) {
    var self = this;
    this.closeWhenDone();
}

function AS_RichText_a8c915f73e9b44e0acf94837a4cf6766(eventobject, linktext, attributes) {
    var self = this;
    alert("clcickec");
    this.onLinkClick();
}

function AS_RichText_b5bf03a5740d4e9aade23203c3a52ba4(eventobject, linktext, attributes) {
    var self = this;
    this.onLinkClick()
}

function AS_Segment_afcf61ab2c924f2a90233f41187b8a74(eventobject, sectionNumber, rowNumber) {
    var self = this;
    this.onRowClick();
}

function AS_Segment_c15f79c5cf1c42d88f3fb10e1e5c2420(eventobject, sectionNumber, rowNumber) {
    var self = this;
    this.onRowClick();
}

function AS_Segment_ce4cc9572abe4dfc97fe8c0a08a08411(eventobject, sectionNumber, rowNumber) {
    var self = this;
    this.onRowClick();
}

function AS_Segment_d3e09723a5254b45ac9431b7e4bdbb06(eventobject, sectionNumber, rowNumber) {
    var self = this;
    this.onRowClick();
}

function AS_Segment_dfc3d2d2383244feb9f2d959e98242bd(eventobject) {
    var self = this;
    alert("onpush");
}

function AS_Segment_dfcca9ad344549429be92720540ec2ef(eventobject) {
    var self = this;
    alert("onpull");
}

function AS_Segment_e44de8566cc347078b9f4cd8c4deec93(seguiWidget, sectionIndex, rowIndex) {
    var self = this;
    alert("on swipe" + rowIndex);
}

function AS_Segment_e7c720104aea46d1ba75d6b9ac331766(eventobject) {
    var self = this;
    alert("End");
}