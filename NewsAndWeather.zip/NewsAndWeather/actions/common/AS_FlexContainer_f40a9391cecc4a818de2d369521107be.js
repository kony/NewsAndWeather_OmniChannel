function AS_FlexContainer_f40a9391cecc4a818de2d369521107be(eventobject) {
    // if(this.view.rchTextDesc.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}