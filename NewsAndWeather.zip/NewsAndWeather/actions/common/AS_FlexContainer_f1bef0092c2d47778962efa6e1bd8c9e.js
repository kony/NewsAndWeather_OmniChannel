function AS_FlexContainer_f1bef0092c2d47778962efa6e1bd8c9e(eventobject) {
    var self = this;
    this.showFirstScreen();
}