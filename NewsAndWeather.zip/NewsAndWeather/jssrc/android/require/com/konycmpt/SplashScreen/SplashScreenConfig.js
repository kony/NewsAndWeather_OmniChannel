define(function() {
    return {
        "properties": [{
            "name": "frmNameToNavigate",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": ["setSplashScreenData", "showFirstScreen", "onGetStarted"],
        "events": []
    }
});