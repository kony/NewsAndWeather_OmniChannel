kony.globals["appid"] = "NewsAndWeather";
kony.globals["defaultLocale"] = "en_US";
kony.globals["locales"] = ["en_US"];
kony.globals["localization"] = "true";
kony.globals["i18nVersion"] = "625543801";