function AS_Button_f9e7b46299ed44238d0f3181e67ddbbc(eventobject) {
    var self = this;
    this.onGetStarted();
}