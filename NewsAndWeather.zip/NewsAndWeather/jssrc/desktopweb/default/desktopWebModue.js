function desktopwebPostAppInit() {
    var Objectbehaviors = {
        "responsive": true
    };
    kony.application.setApplicationBehaviors(Objectbehaviors);
}