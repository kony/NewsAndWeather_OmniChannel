function AS_FlexContainer_e007ca5e942e474fa13735d61e8be717(eventobject) {
    var self = this;
    // if(this.view.rchTextDesc.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}