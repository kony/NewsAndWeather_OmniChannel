function AS_Segment_afcf61ab2c924f2a90233f41187b8a74(eventobject, sectionNumber, rowNumber) {
    var self = this;
    this.onRowClick();
}