define(function() {
    return {
        "properties": [],
        "apis": ["setData"],
        "events": []
    }
});