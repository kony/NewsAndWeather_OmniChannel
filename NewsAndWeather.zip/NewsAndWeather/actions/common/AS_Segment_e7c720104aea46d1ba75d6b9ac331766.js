function AS_Segment_e7c720104aea46d1ba75d6b9ac331766(eventobject) {
    var self = this;
    alert("End");
}