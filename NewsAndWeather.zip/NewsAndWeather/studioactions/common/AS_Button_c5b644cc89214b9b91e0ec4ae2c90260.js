function AS_Button_c5b644cc89214b9b91e0ec4ae2c90260(eventobject) {
    var self = this;
    this.onClickPlayButton(eventobject.id);
}