define({
    AS_AppEvents_bd6a68c68fc846a38eeae091a302680a: function AS_AppEvents_bd6a68c68fc846a38eeae091a302680a(eventobject) {
        var self = this;
        desktopwebPostAppInit();
    }
});