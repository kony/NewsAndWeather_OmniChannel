function AS_FlexContainer_jf582ae16db246a8aa7078364c207959(eventobject) {
    var self = this;
    this.closeWhenDone();
}