define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_f924edd1b0184befa1005251278b1ee4: function AS_Button_f924edd1b0184befa1005251278b1ee4(eventobject) {
        var self = this;
        this.onGetStarted();
    },
    AS_FlexContainer_bb41b71cf12c417ca335e843845f2288: function AS_FlexContainer_bb41b71cf12c417ca335e843845f2288(eventobject) {
        var self = this;
        this.view.segGetStarted.pageSkin = "sknpaging";
    },
    AS_FlexContainer_f1bef0092c2d47778962efa6e1bd8c9e: function AS_FlexContainer_f1bef0092c2d47778962efa6e1bd8c9e(eventobject) {
        var self = this;
        this.showFirstScreen();
    }
});