define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_h818d3ba5c174e54b0566512f4281b85: function AS_Button_h818d3ba5c174e54b0566512f4281b85(eventobject) {
        var self = this;
        this.setCategorySelected(eventobject.id);
    },
    AS_Button_i8aa7caa5b0e40288f907d293df39ec9: function AS_Button_i8aa7caa5b0e40288f907d293df39ec9(eventobject) {
        var self = this;
        this.setCategorySelected(eventobject.id);
    },
    AS_Button_hc6a7f0dc0b14568a3fddd4dd520c480: function AS_Button_hc6a7f0dc0b14568a3fddd4dd520c480(eventobject) {
        var self = this;
        this.setCategorySelected(eventobject.id);
    },
    AS_Button_d4439ebe012b4a9e8ce6fc291e238e27: function AS_Button_d4439ebe012b4a9e8ce6fc291e238e27(eventobject) {
        var self = this;
        this.setCategorySelected(eventobject.id);
    },
    AS_Button_a9e406af7c3a406b825ee36b29b10b3c: function AS_Button_a9e406af7c3a406b825ee36b29b10b3c(eventobject) {
        var self = this;
        this.setCategorySelected(eventobject.id);
    },
    AS_Button_h18e3b32d8f34c3899f9f6ddf32aa56b: function AS_Button_h18e3b32d8f34c3899f9f6ddf32aa56b(eventobject) {
        var self = this;
        this.setCategorySelected(eventobject.id);
    },
    AS_Button_e7e265d183ab4b7a98b42f591d9200ce: function AS_Button_e7e265d183ab4b7a98b42f591d9200ce(eventobject) {
        var self = this;
        this.setCategorySelected(eventobject.id);
    },
    AS_Button_b26062a68e45468cb8cb7f12b1bbb705: function AS_Button_b26062a68e45468cb8cb7f12b1bbb705(eventobject) {
        var self = this;
        this.setCategorySelected(eventobject.id);
    },
    AS_Button_idc2a8928ffb4e66a2406074829f5937: function AS_Button_idc2a8928ffb4e66a2406074829f5937(eventobject) {
        var self = this;
        this.setCategorySelected(eventobject.id);
    },
    AS_Button_g7077d3f46a64fb38ff90fed0f9fbd98: function AS_Button_g7077d3f46a64fb38ff90fed0f9fbd98(eventobject) {
        var self = this;
        this.setCategorySelected(eventobject.id);
    },
    AS_FlexContainer_f5324683470f4a489a4a81cbf92b72f3: function AS_FlexContainer_f5324683470f4a489a4a81cbf92b72f3(eventobject) {
        var self = this;
        this.showHideHamMenu();
    },
    AS_Button_iac7a76a707248a5a6d9af86803739fa: function AS_Button_iac7a76a707248a5a6d9af86803739fa(eventobject) {
        var self = this;
        this.setCategorySelected(eventobject.id);
    },
    AS_Button_c3959ed4474c4c3a9b11a6f15a3282dc: function AS_Button_c3959ed4474c4c3a9b11a6f15a3282dc(eventobject) {
        var self = this;
        this.setCategorySelected(eventobject.id);
    },
    AS_Button_i75f0102a20b4ff38f28b6d21e0268e7: function AS_Button_i75f0102a20b4ff38f28b6d21e0268e7(eventobject) {
        var self = this;
        this.setCategorySelected(eventobject.id);
    },
    AS_Button_f7270c42370e436a9cfffa1aa4a8b9c3: function AS_Button_f7270c42370e436a9cfffa1aa4a8b9c3(eventobject) {
        var self = this;
        this.setCategorySelected(eventobject.id);
    },
    AS_Button_dde86348c87245fb902b27b8c1a4b83d: function AS_Button_dde86348c87245fb902b27b8c1a4b83d(eventobject) {
        var self = this;
        this.setCategorySelected(eventobject.id);
    },
    AS_Button_b20268caa6cf45d3ae209970048c3415: function AS_Button_b20268caa6cf45d3ae209970048c3415(eventobject) {
        var self = this;
        this.setCategorySelected(eventobject.id);
    },
    AS_Button_c9e7f409dbeb49fa904fa44499e0dff8: function AS_Button_c9e7f409dbeb49fa904fa44499e0dff8(eventobject) {
        var self = this;
        this.setCategorySelected(eventobject.id);
    },
    AS_Button_i201542757c54cd7a4075f86132281e7: function AS_Button_i201542757c54cd7a4075f86132281e7(eventobject) {
        var self = this;
        this.setCategorySelected(eventobject.id);
    },
    AS_Button_d9a74fb08e48442b9b44cded8abf3b85: function AS_Button_d9a74fb08e48442b9b44cded8abf3b85(eventobject) {
        var self = this;
        this.setCategorySelected(eventobject.id);
    },
    AS_Button_bd14de4142cb4dca8db48e193c1c4382: function AS_Button_bd14de4142cb4dca8db48e193c1c4382(eventobject) {
        var self = this;
        this.setCategorySelected(eventobject.id);
    },
    AS_Button_eb075f34a88b491ea98a257f8d543a88: function AS_Button_eb075f34a88b491ea98a257f8d543a88(eventobject) {
        var self = this;
        kony.application.openURL('https://community.kony.com/documentation')
    },
    AS_Button_iecaa4e2c0a642d2aa7a8cbe4dee224e: function AS_Button_iecaa4e2c0a642d2aa7a8cbe4dee224e(eventobject) {
        var self = this;
        kony.application.openURL('https://basecamp.kony.com/s/')
    },
    AS_FlexContainer_c7b85a31f54a49e996a780d3119c572c: function AS_FlexContainer_c7b85a31f54a49e996a780d3119c572c(eventobject) {
        var self = this;
        this.closeKnowledgeFramework();
    },
    AS_FlexContainer_g3b61cb7a6b348639e1660888549db6e: function AS_FlexContainer_g3b61cb7a6b348639e1660888549db6e(eventobject) {
        var self = this;
        this.view.flxKnowledgeFramework.isVisible = !this.view.flxKnowledgeFramework.isVisible;
    },
    AS_Form_dd992d2e8c6d4c24b43fcaf1aa714701: function AS_Form_dd992d2e8c6d4c24b43fcaf1aa714701(eventobject) {
        var self = this;
        this.form1PresShow();
    },
    AS_Form_f1e952e551f7495e80012684b648f3e9: function AS_Form_f1e952e551f7495e80012684b648f3e9(eventobject) {
        var self = this;
        this.form1PostShow();
    }
});