define(function() {
    return {
        "properties": [],
        "apis": [],
        "events": []
    }
});