function AS_Image_d320d00c85004d1bb1e06a8e56d810f0(eventobject, x, y) {
    var self = this;
    this.closeWhenDone();
}