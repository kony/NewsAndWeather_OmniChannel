define({ 
	onViewCreated:function(){
      this.view.cursorType = "pointer";
    }
 });