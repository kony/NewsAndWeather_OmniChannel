function AS_Button_ab9d53d5558c4ba1af5045b4154b972d(eventobject) {
    var self = this;
    this.onClickPrev();
}