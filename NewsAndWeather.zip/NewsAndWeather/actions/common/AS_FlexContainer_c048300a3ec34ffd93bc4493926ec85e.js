function AS_FlexContainer_c048300a3ec34ffd93bc4493926ec85e(eventobject) {
    var self = this;
    // if(this.view.lblCodeSnippet.isVisible === true)
    //   this.onClickDisappear(eventobject);
    // else
    //   this.onClickDisplay(eventobject);
    this.showAccord(eventobject.id);
}